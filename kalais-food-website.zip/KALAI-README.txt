KALAI'S FOOD — WEBSITE PACKAGE (Diwali edition)
================================================

FILES
  kalai-index.html        -> customer website  (upload as index.html)
  kalai-admin-6204.html   -> admin dashboard, PIN 1234  (KEEP PRIVATE)
  kalai-rider-3379.html   -> delivery rider app (give to riders only)
  kalai-manifest.webmanifest, kalai-icon-192.png, kalai-icon-512.png,
  kalai-apple-touch-icon.png, sw.js   -> makes it installable as an app

PUBLISH (GitHub Pages, free)
  1. github.com -> New repository -> name "kalais-food" -> Public -> Create
  2. Add file -> Upload files -> drag ALL files above -> Commit changes
     (rename kalai-index.html to index.html BEFORE uploading, or rename after)
  3. Settings -> Pages -> Deploy from a branch -> main -> / (root) -> Save
  4. Wait 3 minutes. Links:
       Website: https://YOURNAME.github.io/kalais-food/
       Admin:   https://YOURNAME.github.io/kalais-food/kalai-admin-6204.html
       Rider:   https://YOURNAME.github.io/kalais-food/kalai-rider-3379.html

DATABASE (do this so orders reach the admin panel automatically)
  1. console.firebase.google.com -> Create project "kalais-food"
  2. Build -> Realtime Database -> Create database -> Singapore
     -> Start in TEST MODE -> Enable
  3. Copy the URL, e.g.
     https://kalais-food-default-rtdb.asia-southeast1.firebasedatabase.app
  4. index.html:                FIREBASE_RTDB_URL = null -> "YOUR URL"
     kalai-admin-6204.html:     FIREBASE_RTDB_URL = null -> "YOUR URL"
     kalai-rider-3379.html:     RTDB = "PASTE_YOUR_..."  -> "YOUR URL"
     (all three must be the SAME url, inside quotes)
  5. Commit. Test: order on phone -> appears in admin within 10 seconds.
  6. IMPORTANT - before 30 days, set permanent rules:
     Realtime Database -> Rules -> replace with:
     { "rules": { "kalaisfood": { ".read": true, ".write": true } } }
     -> Publish

FIRST THINGS TO DO IN ADMIN
  - Settings -> change Admin PIN from 1234
  - Settings -> set your real phone number (currently +91 84389 05628)
  - Settings -> set delivery fee, free-delivery amount, pincodes
  - Settings -> Delivery zones: draw your delivery area on the map
  - Menu -> check prices, upload real photos of your sweets
  - Slots -> adjust the 4 daily delivery slots

WITHOUT the database it still works: orders reach you through the
WhatsApp button customers tap after ordering.
