// Hunt & Eat service worker — enables install-to-home-screen
self.addEventListener("install", (e) => self.skipWaiting());
self.addEventListener("activate", (e) => self.clients.claim());
self.addEventListener("fetch", (e) => {}); // network passthrough
